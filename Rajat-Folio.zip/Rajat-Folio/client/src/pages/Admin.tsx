import { useState } from "react";
import { useAdminAuth, usePortfolioData } from "@/lib/storage";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Lock, User, Calendar, Save, LogOut, Phone } from "lucide-react";
import { initialData } from "@/lib/data";

// Schema for Identity Verification
const verifySchema = z.object({
  email: z.string().email(),
  phone: z.string(),
  dob: z.string(), // Simple string match for "22-09-2000"
});

// Schema for Password
const passwordSchema = z.object({
  password: z.string().min(6, "Password must be at least 6 characters"),
});

export default function Admin() {
  const { isAuthenticated, hasPassword, login, setPassword, logout } = useAdminAuth();
  const { data, updateData } = usePortfolioData();
  const [activeTab, setActiveTab] = useState("personal");

  // Login State
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-100 dark:bg-slate-900 px-4">
        <div className="w-full max-w-md bg-white dark:bg-slate-800 rounded-xl shadow-2xl p-8">
          <div className="text-center mb-8">
            <h1 className="text-2xl font-serif font-bold text-slate-900 dark:text-white">Admin Access</h1>
            <p className="text-slate-500 text-sm mt-2">
              {hasPassword ? "Enter your password to continue" : "Verify identity to set up admin access"}
            </p>
          </div>

          {!hasPassword ? (
            <VerifyIdentityForm onVerified={(pwd) => setPassword(pwd)} />
          ) : (
            <LoginForm onLogin={(pwd) => login(pwd)} />
          )}
        </div>
      </div>
    );
  }

  // Dashboard State
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col">
      <header className="bg-white dark:bg-slate-900 border-b border-gray-200 dark:border-gray-800 px-8 py-4 flex justify-between items-center">
        <h1 className="text-xl font-serif font-bold">CMS Dashboard</h1>
        <button 
          onClick={logout}
          className="flex items-center gap-2 text-sm text-red-500 hover:text-red-600 font-medium"
        >
          <LogOut size={16} />
          Logout
        </button>
      </header>

      <main className="flex-1 max-w-5xl mx-auto w-full p-8">
        <div className="grid grid-cols-12 gap-8">
          {/* Sidebar */}
          <div className="col-span-12 md:col-span-3 space-y-2">
            <button 
              onClick={() => setActiveTab("personal")}
              className={`w-full text-left px-4 py-3 rounded-lg font-medium transition-all ${activeTab === 'personal' ? 'bg-primary text-white shadow-md' : 'bg-white text-slate-600 hover:bg-slate-100'}`}
            >
              Personal Info
            </button>
            <button 
              onClick={() => setActiveTab("projects")}
              className={`w-full text-left px-4 py-3 rounded-lg font-medium transition-all ${activeTab === 'projects' ? 'bg-primary text-white shadow-md' : 'bg-white text-slate-600 hover:bg-slate-100'}`}
            >
              Projects
            </button>
            <button 
              onClick={() => setActiveTab("skills")}
              className={`w-full text-left px-4 py-3 rounded-lg font-medium transition-all ${activeTab === 'skills' ? 'bg-primary text-white shadow-md' : 'bg-white text-slate-600 hover:bg-slate-100'}`}
            >
              Skills
            </button>
          </div>

          {/* Content Area */}
          <div className="col-span-12 md:col-span-9 bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-slate-200 dark:border-slate-800 p-8">
            {activeTab === "personal" && (
              <PersonalInfoForm data={data} onSave={updateData} />
            )}
            {activeTab === "projects" && (
              <div className="text-center py-12 text-slate-400">
                <p>Project editing enabled in full version.</p>
                <p className="text-xs mt-2">Currently showing read-only view of projects in JSON format:</p>
                <pre className="text-left bg-slate-50 p-4 rounded mt-4 overflow-auto text-xs max-h-60">
                  {JSON.stringify(data.projects, null, 2)}
                </pre>
              </div>
            )}
             {activeTab === "skills" && (
              <div className="text-center py-12 text-slate-400">
                <p>Skills editing enabled in full version.</p>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}

// --- Sub-components for forms ---

function VerifyIdentityForm({ onVerified }: { onVerified: (pwd: string) => void }) {
  const [error, setError] = useState("");
  const form = useForm<z.infer<typeof verifySchema>>({
    resolver: zodResolver(verifySchema),
  });
  
  const [step, setStep] = useState(1); // 1 = verify, 2 = set password
  const [tempPwd, setTempPwd] = useState("");

  const onSubmitVerification = (values: z.infer<typeof verifySchema>) => {
    // Hardcoded verification logic as requested
    if (
      values.email === initialData.personalInfo.email &&
      values.phone === initialData.personalInfo.phone &&
      values.dob === initialData.personalInfo.dob
    ) {
      setStep(2);
      setError("");
    } else {
      setError("Identity verification failed. Please check your details.");
    }
  };

  if (step === 2) {
    return (
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1">Set New Admin Password</label>
          <input 
            type="password" 
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary focus:outline-none"
            placeholder="Min 6 characters"
            value={tempPwd}
            onChange={(e) => setTempPwd(e.target.value)}
          />
        </div>
        <button 
          onClick={() => {
            if(tempPwd.length >= 6) onVerified(tempPwd);
            else setError("Password too short");
          }}
          className="w-full bg-primary text-white py-2 rounded-lg font-medium hover:bg-blue-600 transition-colors"
        >
          Save & Login
        </button>
        {error && <p className="text-red-500 text-sm text-center">{error}</p>}
      </div>
    );
  }

  return (
    <form onSubmit={form.handleSubmit(onSubmitVerification)} className="space-y-4">
      <div className="space-y-2">
        <label className="text-sm font-medium">Email Address</label>
        <div className="relative">
          <User className="absolute left-3 top-2.5 text-gray-400" size={18} />
          <input {...form.register("email")} className="pl-10 w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary focus:outline-none" placeholder="Enter verified email" />
        </div>
      </div>
      
      <div className="space-y-2">
        <label className="text-sm font-medium">Phone Number</label>
        <div className="relative">
          <Phone className="absolute left-3 top-2.5 text-gray-400" size={18} />
          <input {...form.register("phone")} className="pl-10 w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary focus:outline-none" placeholder="Enter verified phone" />
        </div>
      </div>

      <div className="space-y-2">
        <label className="text-sm font-medium">Date of Birth (DD-MM-YYYY)</label>
        <div className="relative">
          <Calendar className="absolute left-3 top-2.5 text-gray-400" size={18} />
          <input {...form.register("dob")} className="pl-10 w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary focus:outline-none" placeholder="22-09-2000" />
        </div>
      </div>

      {error && <p className="text-red-500 text-sm text-center">{error}</p>}

      <button type="submit" className="w-full bg-slate-900 text-white py-2 rounded-lg font-medium hover:bg-slate-800 transition-colors">
        Verify Identity
      </button>
    </form>
  );
}

function LoginForm({ onLogin }: { onLogin: (pwd: string) => boolean }) {
  const [pwd, setPwd] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!onLogin(pwd)) {
      setError("Invalid password");
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
       <div className="space-y-2">
        <label className="text-sm font-medium">Password</label>
        <div className="relative">
          <Lock className="absolute left-3 top-2.5 text-gray-400" size={18} />
          <input 
            type="password" 
            value={pwd}
            onChange={(e) => setPwd(e.target.value)}
            className="pl-10 w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary focus:outline-none" 
            placeholder="Enter admin password" 
          />
        </div>
      </div>
      {error && <p className="text-red-500 text-sm text-center">{error}</p>}
      <button type="submit" className="w-full bg-primary text-white py-2 rounded-lg font-medium hover:bg-blue-600 transition-colors">
        Login
      </button>
    </form>
  );
}

function PersonalInfoForm({ data, onSave }: { data: any, onSave: (d: any) => void }) {
  const [formData, setFormData] = useState(data.personalInfo);
  const [msg, setMsg] = useState("");

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({ ...data, personalInfo: formData });
    setMsg("Changes saved successfully!");
    setTimeout(() => setMsg(""), 3000);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-2 gap-6">
        <div className="space-y-2">
          <label className="text-sm font-medium">Full Name</label>
          <input name="name" value={formData.name} onChange={handleChange} className="w-full px-4 py-2 border rounded-lg" />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium">Role Title</label>
          <input name="role" value={formData.role} onChange={handleChange} className="w-full px-4 py-2 border rounded-lg" />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium">Email</label>
          <input name="email" value={formData.email} onChange={handleChange} className="w-full px-4 py-2 border rounded-lg" />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium">Phone</label>
          <input name="phone" value={formData.phone} onChange={handleChange} className="w-full px-4 py-2 border rounded-lg" />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium">Location</label>
          <input name="location" value={formData.location} onChange={handleChange} className="w-full px-4 py-2 border rounded-lg" />
        </div>
      </div>
      
      <div className="space-y-2">
        <label className="text-sm font-medium">Bio</label>
        <textarea name="bio" value={formData.bio} onChange={handleChange} rows={4} className="w-full px-4 py-2 border rounded-lg" />
      </div>

      <div className="flex items-center justify-between pt-4">
        <span className="text-green-600 text-sm font-medium">{msg}</span>
        <button type="submit" className="flex items-center gap-2 bg-slate-900 text-white px-6 py-2 rounded-lg hover:bg-slate-800 transition-colors">
          <Save size={18} />
          Save Changes
        </button>
      </div>
    </form>
  );
}
