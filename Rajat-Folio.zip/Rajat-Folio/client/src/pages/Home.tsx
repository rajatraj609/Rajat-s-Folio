import { Navbar } from "@/components/layout/Navbar";
import { Flipbook } from "@/components/Flipbook";
import { EducationModal } from "@/components/EducationModal";
import { usePortfolioData } from "@/lib/storage";
import { motion } from "framer-motion";
import { Mail, Phone, MapPin, Linkedin, Github } from "lucide-react";
import heroBg from "@assets/generated_images/professional_abstract_background.png";
import { Project } from "@/lib/data";

export default function Home() {
  const { data } = usePortfolioData();

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 font-sans text-slate-900 dark:text-slate-100">
      <Navbar />

      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center pt-16 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img src={heroBg} alt="Background" className="w-full h-full object-cover opacity-10 dark:opacity-5" />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent to-slate-50 dark:to-slate-950"></div>
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full grid md:grid-cols-2 gap-12 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-6"
          >
            <span className="inline-block py-1 px-3 rounded-full bg-primary/10 text-primary text-sm font-semibold tracking-wide uppercase">
              Available for Hire
            </span>
            <h1 className="text-5xl md:text-7xl font-serif font-bold leading-tight">
              Optimizing <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-blue-600">
                Supply Chains
              </span>
            </h1>
            <p className="text-lg md:text-xl text-slate-600 dark:text-slate-400 max-w-lg leading-relaxed">
              I am <strong className="text-slate-900 dark:text-white">{data.personalInfo.name}</strong>, 
              an expert {data.personalInfo.role} helping enterprises streamline logistics with SAP solutions.
            </p>
            <div className="flex gap-4 pt-4">
              <a href="#contact" className="px-8 py-3 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-lg font-medium hover:bg-slate-800 dark:hover:bg-slate-200 transition-colors shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 transition-all">
                Contact Me
              </a>
              <a href="#resume" className="px-8 py-3 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-lg font-medium hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors">
                View Resume
              </a>
            </div>
          </motion.div>

          {/* Abstract Visual Representation of Logistics/Tech */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.2 }}
            className="hidden md:flex justify-center"
          >
            <div className="relative w-80 h-96">
               {/* Decorative elements */}
               <div className="absolute top-0 right-0 w-64 h-64 bg-primary/20 rounded-full blur-3xl"></div>
               <div className="absolute bottom-0 left-0 w-64 h-64 bg-blue-400/20 rounded-full blur-3xl"></div>
               
               {/* Floating Cards Mockup */}
               <div className="absolute top-10 left-0 w-48 p-4 bg-white/80 backdrop-blur shadow-2xl rounded-lg border border-white/50 z-20 transform -rotate-6">
                 <div className="h-2 w-12 bg-gray-200 rounded mb-2"></div>
                 <div className="h-2 w-full bg-gray-100 rounded mb-1"></div>
                 <div className="h-2 w-3/4 bg-gray-100 rounded"></div>
                 <div className="mt-4 flex justify-between items-center">
                   <div className="h-6 w-6 rounded-full bg-green-100 flex items-center justify-center text-[10px] text-green-600">✓</div>
                   <div className="text-xs font-mono text-gray-400">SAP EWM</div>
                 </div>
               </div>

               <div className="absolute bottom-20 right-0 w-56 p-5 bg-white shadow-2xl rounded-lg border border-slate-100 z-30 transform rotate-3">
                 <div className="flex gap-3 mb-3">
                   <div className="h-8 w-8 rounded bg-primary/20"></div>
                   <div>
                      <div className="h-2 w-20 bg-gray-200 rounded mb-1"></div>
                      <div className="h-2 w-12 bg-gray-100 rounded"></div>
                   </div>
                 </div>
                 <div className="space-y-2">
                   <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                     <div className="h-full w-3/4 bg-primary"></div>
                   </div>
                   <div className="flex justify-between text-[10px] text-gray-400">
                     <span>Optimization</span>
                     <span>75%</span>
                   </div>
                 </div>
               </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* About & Stats */}
      <section id="about" className="py-24 bg-white dark:bg-slate-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-12 gap-12">
             <div className="md:col-span-4">
                <h2 className="text-3xl font-serif font-bold mb-6">About Me</h2>
                <div className="w-12 h-1 bg-primary mb-6"></div>
                <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                  {data.personalInfo.bio}
                </p>
                <div className="mt-8 pt-8 border-t border-slate-100 dark:border-slate-800 grid grid-cols-2 gap-6">
                   <div>
                     <span className="block text-3xl font-bold text-slate-900 dark:text-white">4+</span>
                     <span className="text-sm text-slate-500">Years Experience</span>
                   </div>
                   <div>
                     <span className="block text-3xl font-bold text-slate-900 dark:text-white">10+</span>
                     <span className="text-sm text-slate-500">Projects Delivered</span>
                   </div>
                </div>
             </div>
             
             {/* Education Card Modal */}
             <div className="md:col-span-8 flex flex-col justify-center items-center md:items-start bg-slate-50 dark:bg-slate-800/50 p-8 rounded-2xl">
                <h3 className="text-xl font-medium mb-8 text-center md:text-left w-full">Education</h3>
                <EducationModal education={data.education} />
             </div>
          </div>
        </div>
      </section>

      {/* Interactive Resume */}
      <section id="resume" className="py-24 bg-slate-100 dark:bg-slate-950 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-serif font-bold mb-4">Interactive Resume</h2>
          <p className="text-slate-500 max-w-xl mx-auto">Flip through to see my detailed qualifications and professional journey.</p>
        </div>
        <Flipbook data={data} />
      </section>

      {/* Projects */}
      <section id="projects" className="py-24 bg-white dark:bg-slate-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-serif font-bold mb-4">Featured Projects</h2>
            <div className="w-16 h-1 bg-primary mx-auto"></div>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {data.projects.map((project: Project) => (
              <motion.div 
                key={project.id}
                whileHover={{ y: -5 }}
                className="group p-8 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-100 dark:border-slate-700 hover:shadow-xl transition-all duration-300"
              >
                <h3 className="text-xl font-bold mb-2 group-hover:text-primary transition-colors">{project.title}</h3>
                <p className="text-sm text-primary font-medium mb-4">{project.role}</p>
                <p className="text-slate-600 dark:text-slate-400 mb-6 text-sm leading-relaxed">{project.description}</p>
                <div className="flex flex-wrap gap-2">
                  {project.technologies.map((tech: string, idx: number) => (
                    <span key={idx} className="px-2 py-1 text-[10px] uppercase tracking-wider font-semibold bg-white dark:bg-slate-900 text-slate-500 rounded border border-slate-200 dark:border-slate-700">
                      {tech}
                    </span>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer / Contact */}
      <footer id="contact" className="bg-slate-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-12">
            <div>
              <h3 className="text-2xl font-serif font-bold mb-6">RR.</h3>
              <p className="text-slate-400 text-sm leading-relaxed max-w-xs">
                Professional SAP Consultant delivering excellence in supply chain management and logistics execution.
              </p>
            </div>
            
            <div>
              <h4 className="text-lg font-medium mb-6">Contact Info</h4>
              <div className="space-y-4">
                <a href={`mailto:${data.personalInfo.email}`} className="flex items-center gap-3 text-slate-400 hover:text-white transition-colors">
                  <Mail size={18} />
                  <span>{data.personalInfo.email}</span>
                </a>
                <div className="flex items-center gap-3 text-slate-400">
                  <Phone size={18} />
                  <span>{data.personalInfo.phone}</span>
                </div>
                <div className="flex items-center gap-3 text-slate-400">
                  <MapPin size={18} />
                  <span>{data.personalInfo.location}</span>
                </div>
              </div>
            </div>

            <div>
              <h4 className="text-lg font-medium mb-6">Social</h4>
              <div className="flex gap-4">
                <a href="#" className="p-2 bg-slate-800 rounded-full hover:bg-primary transition-colors">
                  <Linkedin size={20} />
                </a>
                <a href="#" className="p-2 bg-slate-800 rounded-full hover:bg-primary transition-colors">
                  <Github size={20} />
                </a>
              </div>
            </div>
          </div>
          
          <div className="mt-16 pt-8 border-t border-slate-800 text-center text-slate-500 text-sm">
            © {new Date().getFullYear()} Rajat Raj. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}
