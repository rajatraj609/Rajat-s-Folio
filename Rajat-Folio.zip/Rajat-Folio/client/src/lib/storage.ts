import { useState, useEffect } from "react";
import { PortfolioData, initialData } from "./data";

const STORAGE_KEY = "rajat_portfolio_data";
const AUTH_KEY = "rajat_admin_auth";

export const usePortfolioData = () => {
  const [data, setData] = useState<PortfolioData>(initialData);

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        setData(JSON.parse(stored));
      } catch (e) {
        console.error("Failed to parse stored data", e);
      }
    }
  }, []);

  const updateData = (newData: PortfolioData) => {
    setData(newData);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newData));
  };

  return { data, updateData };
};

export const useAdminAuth = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [hasPassword, setHasPassword] = useState(false);

  useEffect(() => {
    // Check if we are logged in (session specific in this mock, or persisted)
    // For this mock, let's persist login state in sessionStorage
    const sessionAuth = sessionStorage.getItem("admin_logged_in");
    if (sessionAuth === "true") setIsAuthenticated(true);

    // Check if a password has ever been set
    const storedAuth = localStorage.getItem(AUTH_KEY);
    if (storedAuth) setHasPassword(true);
  }, []);

  const login = (password: string) => {
    const storedAuth = localStorage.getItem(AUTH_KEY);
    if (storedAuth && storedAuth === password) {
      setIsAuthenticated(true);
      sessionStorage.setItem("admin_logged_in", "true");
      return true;
    }
    return false;
  };

  const setPassword = (password: string) => {
    localStorage.setItem(AUTH_KEY, password);
    setHasPassword(true);
    setIsAuthenticated(true);
    sessionStorage.setItem("admin_logged_in", "true");
  };

  const logout = () => {
    setIsAuthenticated(false);
    sessionStorage.removeItem("admin_logged_in");
  };

  return { isAuthenticated, hasPassword, login, setPassword, logout };
};
