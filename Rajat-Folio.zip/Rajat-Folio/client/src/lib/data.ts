
export interface Project {
  id: string;
  title: string;
  role: string;
  description: string;
  technologies: string[];
}

export interface Skill {
  category: string;
  items: string[];
}

export interface PortfolioData {
  personalInfo: {
    name: string;
    role: string;
    email: string;
    phone: string;
    dob: string;
    location: string;
    bio: string;
  };
  skills: Skill[];
  projects: Project[];
  education: {
    degree: string;
    institution: string;
    year: string;
    description: string;
  }[];
}

export const initialData: PortfolioData = {
  personalInfo: {
    name: "Rajat Raj",
    role: "SAP MM/EWM Consultant",
    email: "rajatraj609@gmail.com",
    phone: "8862813467",
    dob: "22-09-2000",
    location: "India",
    bio: "Experienced SAP Consultant specializing in Materials Management (MM) and Extended Warehouse Management (EWM). Proven track record of optimizing supply chain processes and implementing robust SAP solutions for enterprise clients.",
  },
  skills: [
    {
      category: "SAP Modules",
      items: ["SAP MM", "SAP EWM", "S/4HANA", "WM", "Logistics Execution"]
    },
    {
      category: "Technical Skills",
      items: ["ABAP Debugging", "IDOCs", "LSMW", "SAP Fiori", "Data Migration"]
    },
    {
      category: "Functional Expertise",
      items: ["Procurement", "Inventory Management", "Warehouse Operations", "RF Framework", "Inbound/Outbound Logistics"]
    }
  ],
  projects: [
    {
      id: "1",
      title: "Warehouse Transformation Project",
      role: "Lead SAP EWM Consultant",
      description: "Led the implementation of SAP EWM for a major automotive parts manufacturer, improving inventory accuracy by 25%.",
      technologies: ["SAP EWM", "S/4HANA", "RF Devices"]
    },
    {
      id: "2",
      title: "Procurement Optimization",
      role: "SAP MM Consultant",
      description: "Streamlined procurement processes for a retail giant, implementing automated PO creation and vendor evaluation strategies.",
      technologies: ["SAP MM", "Ariba", "Integration"]
    },
    {
      id: "3",
      title: "Global Rollout",
      role: "Functional Consultant",
      description: "Participated in a global SAP rollout across 5 countries, ensuring standardization of logistic processes.",
      technologies: ["SAP MM/WM", "Cross-functional Integration"]
    }
  ],
  education: [
    {
      degree: "Bachelor of Technology",
      institution: "Prestigious Technical University",
      year: "2018 - 2022",
      description: "Specialized in Computer Science with a focus on Enterprise Systems."
    }
  ]
};
