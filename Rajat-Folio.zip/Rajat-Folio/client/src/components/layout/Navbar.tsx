import { Link } from "wouter";
import { User, Menu, X } from "lucide-react";
import { useState } from "react";

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-gray-200 dark:border-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <Link href="/">
            <a className="text-2xl font-serif font-bold text-primary tracking-tight cursor-pointer">
              RR.
            </a>
          </Link>

          {/* Desktop Menu */}
          <div className="hidden md:flex space-x-8 items-center">
            <a href="#about" className="text-sm font-medium hover:text-primary transition-colors">About</a>
            <a href="#skills" className="text-sm font-medium hover:text-primary transition-colors">Skills</a>
            <a href="#projects" className="text-sm font-medium hover:text-primary transition-colors">Projects</a>
            <a href="#resume" className="text-sm font-medium hover:text-primary transition-colors">Resume</a>
            <Link href="/admin">
              <a className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors" title="Admin Login">
                <User size={20} />
              </a>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button onClick={() => setIsOpen(!isOpen)} className="p-2 text-gray-600">
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-white dark:bg-slate-900 border-b border-gray-200 dark:border-gray-800 absolute w-full">
          <div className="px-4 pt-2 pb-6 space-y-2">
            <a href="#about" onClick={() => setIsOpen(false)} className="block py-2 text-base font-medium">About</a>
            <a href="#skills" onClick={() => setIsOpen(false)} className="block py-2 text-base font-medium">Skills</a>
            <a href="#projects" onClick={() => setIsOpen(false)} className="block py-2 text-base font-medium">Projects</a>
            <a href="#resume" onClick={() => setIsOpen(false)} className="block py-2 text-base font-medium">Resume</a>
            <Link href="/admin">
              <a onClick={() => setIsOpen(false)} className="block py-2 text-base font-medium text-primary">Admin Access</a>
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
}
