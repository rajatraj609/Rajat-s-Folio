import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";
import { ChevronLeft, ChevronRight, Download } from "lucide-react";
import { PortfolioData } from "@/lib/data";

interface FlipbookProps {
  data: PortfolioData;
}

export function Flipbook({ data }: FlipbookProps) {
  const [page, setPage] = useState(0);
  const totalPages = 3; // Cover, Details, Experience

  const nextPage = () => {
    if (page < totalPages - 1) setPage(page + 1);
  };

  const prevPage = () => {
    if (page > 0) setPage(page - 1);
  };

  return (
    <div className="relative w-full max-w-4xl mx-auto h-[600px] flex items-center justify-center perspective-1000">
      {/* Controls */}
      <button 
        onClick={prevPage} 
        disabled={page === 0}
        className="absolute left-0 md:-left-12 z-20 p-2 rounded-full bg-white shadow-lg disabled:opacity-30 hover:bg-gray-50 transition-colors"
      >
        <ChevronLeft size={24} />
      </button>

      <button 
        onClick={nextPage} 
        disabled={page === totalPages - 1}
        className="absolute right-0 md:-right-12 z-20 p-2 rounded-full bg-white shadow-lg disabled:opacity-30 hover:bg-gray-50 transition-colors"
      >
        <ChevronRight size={24} />
      </button>

      {/* Book Container */}
      <div className="relative w-[350px] md:w-[450px] h-[580px] bg-transparent preserve-3d">
        <AnimatePresence mode="wait">
          {page === 0 && (
            <PageWrapper key="cover" page={0}>
              <div className="h-full flex flex-col items-center justify-center text-center p-8 bg-slate-900 text-white border-l-4 border-slate-700 rounded-r-sm shadow-2xl">
                <div className="w-full h-full border border-slate-700/50 p-6 flex flex-col items-center justify-center">
                  <h1 className="text-4xl md:text-5xl font-serif font-bold mb-4">{data.personalInfo.name}</h1>
                  <h2 className="text-xl md:text-2xl text-slate-300 font-light mb-8">{data.personalInfo.role}</h2>
                  <div className="w-16 h-1 bg-primary mb-8"></div>
                  <p className="text-sm text-slate-400 uppercase tracking-widest">Interactive Resume</p>
                </div>
              </div>
            </PageWrapper>
          )}

          {page === 1 && (
            <PageWrapper key="details" page={1}>
               <div className="h-full bg-white p-8 md:p-12 shadow-xl rounded-r-sm text-slate-800 flex flex-col">
                  <h3 className="text-2xl font-serif font-bold mb-6 border-b pb-2">Contact & Summary</h3>
                  
                  <div className="space-y-4 mb-8 text-sm md:text-base">
                    <div className="flex justify-between border-b border-gray-100 pb-1">
                      <span className="font-semibold text-slate-500">Email</span>
                      <span>{data.personalInfo.email}</span>
                    </div>
                    <div className="flex justify-between border-b border-gray-100 pb-1">
                      <span className="font-semibold text-slate-500">Phone</span>
                      <span>{data.personalInfo.phone}</span>
                    </div>
                    <div className="flex justify-between border-b border-gray-100 pb-1">
                      <span className="font-semibold text-slate-500">Location</span>
                      <span>{data.personalInfo.location}</span>
                    </div>
                    <div className="flex justify-between border-b border-gray-100 pb-1">
                      <span className="font-semibold text-slate-500">DOB</span>
                      <span>{data.personalInfo.dob}</span>
                    </div>
                  </div>

                  <div className="prose prose-sm text-slate-600 leading-relaxed">
                    <p>{data.personalInfo.bio}</p>
                  </div>
               </div>
            </PageWrapper>
          )}

          {page === 2 && (
            <PageWrapper key="skills" page={2}>
              <div className="h-full bg-white p-8 md:p-12 shadow-xl rounded-r-sm text-slate-800 flex flex-col">
                <h3 className="text-2xl font-serif font-bold mb-6 border-b pb-2">Skills & Expertise</h3>
                
                <div className="space-y-6 overflow-y-auto pr-2 custom-scrollbar">
                  {data.skills.map((skillGroup, idx) => (
                    <div key={idx}>
                      <h4 className="font-semibold text-primary mb-2">{skillGroup.category}</h4>
                      <div className="flex flex-wrap gap-2">
                        {skillGroup.items.map((skill, sIdx) => (
                          <span key={sIdx} className="px-2 py-1 bg-slate-100 text-xs text-slate-700 rounded-sm border border-slate-200">
                            {skill}
                          </span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-auto pt-6 border-t">
                  <button className="w-full flex items-center justify-center gap-2 bg-slate-900 text-white py-3 px-4 rounded hover:bg-slate-800 transition-colors">
                    <Download size={18} />
                    <span>Download Full PDF</span>
                  </button>
                </div>
              </div>
            </PageWrapper>
          )}
        </AnimatePresence>

        {/* Paper texture overlay for realism */}
        <div className="absolute inset-0 pointer-events-none bg-gradient-to-l from-black/5 to-transparent z-10 rounded-r-sm"></div>
      </div>
    </div>
  );
}

function PageWrapper({ children, page }: { children: React.ReactNode; page: number }) {
  return (
    <motion.div
      initial={{ rotateY: 90, opacity: 0 }}
      animate={{ rotateY: 0, opacity: 1 }}
      exit={{ rotateY: -90, opacity: 0 }}
      transition={{ duration: 0.6, ease: "easeInOut" }}
      style={{ transformOrigin: "left center" }}
      className="absolute inset-0 w-full h-full bg-white shadow-2xl rounded-r-sm overflow-hidden backface-hidden"
    >
      {children}
    </motion.div>
  );
}
