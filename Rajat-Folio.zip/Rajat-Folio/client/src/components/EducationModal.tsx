import {
  Dialog,
  DialogContent,
  DialogTrigger,
} from "@/components/ui/dialog";
import { GraduationCap } from "lucide-react";
import { PortfolioData } from "@/lib/data";
import universityImage from "@assets/generated_images/modern_university_campus_background.png";
import { motion } from "framer-motion";

interface EducationModalProps {
  education: PortfolioData["education"];
}

export function EducationModal({ education }: EducationModalProps) {
  // Assuming single education entry for simplicity as per prototype
  const edu = education[0];

  return (
    <Dialog>
      <DialogTrigger asChild>
        <button className="group relative overflow-hidden rounded-xl bg-white shadow-lg hover:shadow-xl transition-all duration-300 w-full md:w-auto min-w-[300px] text-left cursor-pointer">
          <div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
          <div className="p-6 flex items-start gap-4">
            <div className="p-3 bg-primary/10 rounded-lg text-primary">
              <GraduationCap size={24} />
            </div>
            <div>
              <h3 className="font-serif font-bold text-lg text-slate-900">{edu.degree}</h3>
              <p className="text-slate-500 text-sm mt-1">{edu.institution}</p>
              <p className="text-xs text-slate-400 mt-2 font-mono">{edu.year}</p>
              <p className="text-xs text-primary mt-3 font-medium flex items-center gap-1">
                View Details <span className="text-[10px] transform group-hover:translate-x-1 transition-transform">→</span>
              </p>
            </div>
          </div>
        </button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px] p-0 overflow-hidden border-0">
        <div className="relative h-[400px] w-full">
          {/* Background Image with Blur */}
          <div 
            className="absolute inset-0 bg-cover bg-center"
            style={{ 
              backgroundImage: `url(${universityImage})`,
              filter: "blur(4px) brightness(0.6)"
            }}
          ></div>
          
          {/* Content Overlay */}
          <div className="absolute inset-0 z-10 flex flex-col items-center justify-center p-8 text-center text-white bg-black/20">
            <motion.div 
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.2 }}
            >
              <div className="w-16 h-16 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center mx-auto mb-6 ring-1 ring-white/50">
                <GraduationCap size={32} className="text-white" />
              </div>
              <h2 className="text-3xl md:text-4xl font-serif font-bold mb-2 drop-shadow-lg">{edu.institution}</h2>
              <p className="text-xl font-light text-slate-100 mb-6 drop-shadow-md">{edu.degree}</p>
              
              <div className="inline-block px-4 py-1 bg-white/20 backdrop-blur-sm rounded-full border border-white/30 text-sm font-medium tracking-wide mb-6">
                Class of {edu.year.split('-')[1].trim()}
              </div>

              <p className="text-slate-200 max-w-md mx-auto leading-relaxed drop-shadow-sm text-sm md:text-base">
                {edu.description}
              </p>
            </motion.div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
